use mirajazz::{
    device::DeviceQuery,
    types::{HidDeviceInfo, ImageFormat, ImageMirroring, ImageMode, ImageRotation},
};

// Device namespace: must be unique between all the plugins, 2 characters long and match `DeviceNamespace` field in `manifest.json`
// Previously used "99" from the source project akp153, now changed to "d6" for this plugin
pub const DEVICE_NAMESPACE: &str = "d6";

pub const ROW_COUNT: usize = 3;
pub const COL_COUNT: usize = 5;
pub const KEY_COUNT: usize = ROW_COUNT * COL_COUNT;
pub const ENCODER_COUNT: usize = 0;

#[derive(Debug, Clone)]
pub enum Kind {
    AMPGD6,
    AMPGD6V2,
}

pub const FIFINE_VID: u16 = 0x3142;
pub const AMPGD6_PID: u16 = 0x0007;
/// Second hardware revision of the FIFINE Ampligame D6 ("D6 Pro").
/// Reports itself as `HOTSPOTEKUSB HID DEMO`, has 112x112 LCDs and needs the
/// larger (1024-byte) packet protocol, see `Kind::protocol_version` below.
pub const AMPGD6_V2_PID: u16 = 0x0060;

// Map all queries to usage page 65440 and usage id 1 for now
pub const AMPGD6_QUERY: DeviceQuery = DeviceQuery::new(65440, 1, FIFINE_VID, AMPGD6_PID);
pub const AMPGD6_V2_QUERY: DeviceQuery = DeviceQuery::new(65440, 1, FIFINE_VID, AMPGD6_V2_PID);

// IMPORTANT: both PIDs have to be present here. `list_devices()` filters at
// enumeration time, so a device missing from `QUERIES` is never even reported
// to `Kind::from_vid_pid` and silently dropped (see issue #7).
pub const QUERIES: [DeviceQuery; 2] = [AMPGD6_QUERY, AMPGD6_V2_QUERY];

/// Returns correct image format for device kind and key
pub fn get_image_format_for_key(kind: &Kind, _key: u8) -> ImageFormat {
    // Panel sizes, verified on real hardware:
    // - 0x0007 units have 100x100 LCDs (FIFINE/vendor "StreamDock293s" software uses
    //   96x96, every independent re-implementation uses 100x100; 105 - as sent by
    //   earlier plugin versions - overflows the fixed framebuffer stride and the
    //   firmware ends up discarding or smearing the artwork)
    // - 0x0060 units have 112x112 LCDs (see issues #6 and #7)
    let size = match kind {
        Kind::AMPGD6 => (100, 100),
        Kind::AMPGD6V2 => (112, 112),
    };

    ImageFormat {
        mode: ImageMode::JPEG,
        size,
        rotation: ImageRotation::Rot180, // AMPGD6 needs 180° rotation
        mirror: ImageMirroring::None,  // No mirroring needed for AMPGD6
    }
}

impl Kind {
    /// Matches devices VID+PID pairs to correct kinds
    pub fn from_vid_pid(vid: u16, pid: u16) -> Option<Self> {
        match vid {
            FIFINE_VID => match pid {
                AMPGD6_PID => Some(Kind::AMPGD6),
                AMPGD6_V2_PID => Some(Kind::AMPGD6V2),
                _ => None,
            },
            _ => None,
        }
    }

    /// Returns protocol version for device
    pub fn protocol_version(&self) -> usize {
        match self {
            Self::AMPGD6 => 1, // Back to version 1 - the error might be related to button count or initialization
            // The 0x0060 revision reports a 1024-byte maximum output report.
            // mirajazz only switches its packet size from 512 to 1024 bytes for
            // protocol version >= 2: on version 1 every write (brightness, clear,
            // image chunks, the STP commit) leaves as 513 bytes instead of 1025
            // and the firmware silently discards it while every call still
            // returns Ok(()). Input reports are unaffected, which is why keys
            // keep working while the screens stay black (see issue #7).
            // Version 3 additionally reads the key state byte from input
            // reports, which matches this revision's behaviour.
            Self::AMPGD6V2 => 3,
        }
    }

    /// There is no point relying on manufacturer/device names reported by the USB stack,
    /// so we return custom names for all the kinds of devices
    pub fn human_name(&self) -> String {
        match &self {
            Self::AMPGD6 => "FIFINE Ampligame D6",
            Self::AMPGD6V2 => "FIFINE Ampligame D6 (Rev. 2)",
        }
        .to_string()
    }

    /// Because "v1" devices all share the same serial number, use custom suffix to be able to connect
    /// two devices with the different revisions at the same time
    pub fn id_suffix(&self) -> String {
        match &self {
            Self::AMPGD6 => "AMPGD6",
            Self::AMPGD6V2 => "AMPGD6V2",
        }
        .to_string()
    }
}

#[derive(Debug, Clone)]
pub struct CandidateDevice {
    pub id: String,
    pub dev: HidDeviceInfo,
    pub kind: Kind,
}
