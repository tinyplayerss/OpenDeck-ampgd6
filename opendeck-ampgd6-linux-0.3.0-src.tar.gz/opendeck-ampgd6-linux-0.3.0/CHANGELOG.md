# Changelog

## [0.3.0] - 2026-11-10

### 🐛 Bug Fixes

- Fix icons not rendering on the 3142:0060 hardware revision: it reports a
  1024-byte output report, but the plugin negotiated the 512-byte packet
  protocol, so the firmware silently discarded every image write while all
  calls still returned success. The revision now gets its own
  `Kind::AMPGD6V2` running the larger-packet protocol (#7, #8)
- Fix icons rendering garbled/unfilled on the 3142:0007 revision: images are
  now sent at the correct 100x100 panel size instead of 105x105, which
  overflowed the fixed framebuffer stride
- Use the correct 112x112 panel size for the 3142:0060 revision (#6, #7)
- Pre-scale button images with Lanczos3 before handing them to mirajazz, so
  the 144x144 images OpenDeck always sends don't get nearest-neighbour
  aliased on the way down to 100x100/112x112 (#7)
- Send a periodic keep-alive (CONNECT) frame every 5 seconds - without it the
  MCU puts the LCDs to sleep and newly written images stop appearing
- Commit clears with an explicit STP frame: mirajazz's flush() skips the
  commit when the image cache is empty, so cleared buttons kept their stale
  icons when switching profiles

### 🚀 Features

- Linux-only build: dropped the macOS and Windows binaries and manifest
  entries

## [0.2.2] - 2026-04-19

### 🐛 Bug Fixes

- Fix ghost click on profile switch by forcing the event reader to protocol v3 and reading the actual key state byte instead of emitting a synthetic down+up pair (thanks @theGENreel, #3)
- Sync manifest.json version with Cargo.toml

## [0.2.1] - 2026-02-23

### 🚀 Features

- Add build to release

### 🐛 Bug Fixes

- correct cargo edition to 2024
- remove ref of template plugin name

## [0.2.0] - 2026-01-23

### 🚀 Features

- Adapt size of logo for Ampligame D6 - #1
- Change namespace from 99 to d6 to avoid duplication with the akp153 plugin

## [0.1.0] - 2025-11-28

### 🚀 Features

- First version, fork for akp153 Plugin with modification to work with Fifine Ampligame D6
