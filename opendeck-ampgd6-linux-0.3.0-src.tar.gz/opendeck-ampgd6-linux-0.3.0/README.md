![Plugin Icon](assets/icon.png)

# OpenDeck FIFINE Ampligame D6 Plugin

An unofficial plugin for FIFINE Ampligame D6 device

## OpenDeck version

Requires OpenDeck 2.5.0 or newer

## Supported devices

- FIFINE Ampligame D6 (3142:0007)
- FIFINE Ampligame D6 second revision / "D6 Pro" (3142:0060)

## Platform support

- Linux: Guaranteed, if stuff breaks - I'll probably catch it before public release
- Mac: Not supported in this build
- Windows: Not supported in this build

This fork builds a Linux-only version. Make sure the udev rules from
`40-opendeck-ampgd6.rules` are installed (both device revisions are covered)
so OpenDeck can access the device without root., it's up to you to contribute fixes

## Installation

1. Download an archive from [releases](https://github.com/shugotekitten/opendeck-ampgd6/releases)
2. In OpenDeck: Plugins -> Install from file
3. Linux: Download [udev rules](./40-opendeck-ampgd6.rules) and install them by copying into `/etc/udev/rules.d/` and running `sudo udevadm control --reload-rules`
4. Unplug and plug again the device, restart OpenDeck

## Device specifications

- Layout: 3 rows × 5 columns (15 buttons)
- Protocol version: 1

## Building

### Prerequisites

You'll need:

- A Linux OS of some sort
- Rust 1.87 and up with `x86_64-unknown-linux-gnu` and `x86_64-pc-windows-gnu` targets installed
- Docker
- [just](https://just.systems)

### Preparing environment

```sh
$ just prepare
```

This will build docker image for macOS crosscompilation

### Building a release package

```sh
$ just package
```

## Acknowledgments

This plugin is heavily based on work by contributors of [elgato-streamdeck](https://github.com/streamduck-org/elgato-streamdeck) crate
